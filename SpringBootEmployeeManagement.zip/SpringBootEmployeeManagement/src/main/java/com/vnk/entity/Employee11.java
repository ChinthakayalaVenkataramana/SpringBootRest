package com.vnk.entity;
import jakarta.annotation.Nonnull;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@RequiredArgsConstructor
public class Employee11 {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer empId;
@Nonnull
private String name;
@Nonnull
private String mail;
@Nonnull
private Long mobile;
@Nonnull
private String desg;
}
