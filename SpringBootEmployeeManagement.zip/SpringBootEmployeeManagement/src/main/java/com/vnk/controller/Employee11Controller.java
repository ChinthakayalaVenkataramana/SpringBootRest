package com.vnk.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.vnk.entity.Employee11;
import com.vnk.service.EmployeeService;

@RestController
public class Employee11Controller {
@Autowired
private EmployeeService employeeService;
@GetMapping("/")
public ResponseEntity<?> home(){
	return new ResponseEntity<String>("Welcome employee Operations",HttpStatus.ACCEPTED);
}
@PostMapping("/addEmployee")
public String addEmployee(@RequestBody Employee11 employee11) {
	return employeeService.addEmployee(employee11);
}
@PutMapping("/updateEmployee/{id}")
public ResponseEntity<String> update(@PathVariable("id")Integer id,@RequestBody Employee11 employee11){
	return new ResponseEntity<String>(employeeService.updateEmployee(employee11),HttpStatus.OK);
}
@GetMapping("/viewAll")
public ResponseEntity<String> viewAll() {
	return new ResponseEntity<String>(employeeService.findAllEmployees().toString(),HttpStatus.ACCEPTED);
}
@GetMapping("/view/{id}")
public ResponseEntity<String> viewById(@PathVariable("id")Integer id) {
	return new ResponseEntity<String>(employeeService.findByEmployeeId(id).toString(),HttpStatus.ACCEPTED);
}
@DeleteMapping("/delete/{id}")
public ResponseEntity<String> deleteById(@PathVariable("id")Integer id) {
	return new ResponseEntity<String>(employeeService.deleteEmployee(id).toString(),HttpStatus.ACCEPTED);
}
}
