package com.vnk.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.vnk.entity.Employee11;
import com.vnk.repository.EmployeeRepository;
@Service
public class EmployeeService implements IEmployeeService {
	@Autowired
	private EmployeeRepository repository;

	@Override
	public String addEmployee(Employee11 employee) {
		if (employee.equals(null)) {
			return "Id npt found";
		} else {
			Employee11 save = repository.save(employee);
			return "employee added successfully " + save.getName();
		}
	}

	@Override
	public Employee11 findByEmployeeId(Integer id) {
		if (!repository.existsById(id)) {
			return null;
		} else {
			return repository.getReferenceById(id);
		}
	}

	@Override
	public List<Employee11> findAllEmployees() {
		return repository.findAll();
	}

	@Override
	public String updateEmployee(Employee11 employee) {
		if (!repository.existsById(employee.getEmpId())) {
			return "Id npt found";
		} else {
			return repository.save(employee).getEmpId() + " Employee updated successfully ";
		}
	}

	@Override
	public String deleteEmployee(Integer id) {
		if (!repository.existsById(id)) {
			return "Id npt found";
		} else {
			repository.deleteById(id);
			return "employee Deleted successfully " + id;
		}
	}
}
