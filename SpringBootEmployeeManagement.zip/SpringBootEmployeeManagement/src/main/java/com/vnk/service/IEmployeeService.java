package com.vnk.service;

import java.util.List;

import com.vnk.entity.Employee11;

public interface IEmployeeService {
public String addEmployee(Employee11 employee);
public Employee11 findByEmployeeId(Integer id);
public List<Employee11> findAllEmployees();
public String updateEmployee(Employee11 employee);
public String deleteEmployee(Integer id);
}
