package com.vnk.config;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springdoc.core.GroupedOpenApi;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
public class SwaggerApiConfig {

    @Bean
    public GroupedOpenApi publicApi() {
        return GroupedOpenApi.builder()
                .group("springboot-public") // You can create multiple groups for different APIs
                .pathsToMatch("/api/**") // You can specify paths to be included
                .build();
    }

    @Bean
    public Info apiInfo() {
        return new Info().title("Spring Boot API")
                .description("This is a sample Spring Boot API documentation")
                .version("v1.0");
    }
}
