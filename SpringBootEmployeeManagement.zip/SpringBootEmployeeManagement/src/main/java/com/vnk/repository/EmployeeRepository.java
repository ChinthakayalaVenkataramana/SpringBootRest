package com.vnk.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vnk.entity.Employee11;

public interface EmployeeRepository extends JpaRepository<Employee11, Integer> {
	
}
